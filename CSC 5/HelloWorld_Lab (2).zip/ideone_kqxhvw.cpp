/*
  David W. Smith
  January 6th, 2013
  First Program
*/

//System Libraries

#include <cstdlib>
#include <iostream>
using namespace std;

//Global Constants

//Functional Prototypes

//Execution Begins Here

int main(int argc, char *argv[]){
    //Print the string "Hello World"
    cout<<"Hello World"<<endl;
    //Exit, stage right!
    return 0;
}
