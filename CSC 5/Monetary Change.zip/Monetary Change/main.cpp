/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on January 15, 2014, 9:05 AM
 */
//System Libraries
#include <iostream>
using namespace std;

//Global Constants
const int DLR_VAL=100; //100 cents
const int H_VAL=50; //50 cents
const int Q_VAL=25; //25 cents
const int D_VAL=10; //10 cents
const int N_VAL=5; // 5 cents
const int P_VAL=1; // 1 cent

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Define Local Variables
    float price,amtTend;
    char answer;
    //Loop to ask numerous times
    //for change calculation.
    do {
        cout << "What is the price of the item?" << endl;
        cin >> price;
        do {
                cout << "what was received/tendered?" << endl;
                cout >> "Has to be greater than the price" << endl;
                cin >> amtTend;
        } while(amtTend < price);
        //Convert to pennies
        int nPrice = price*DLR_VAL;
        int mtTend=amtTend*DLR_VAL;
        int change = mtTend - nPrice;
        //Calc number of half-dollars
        int nHalf = change / H_VAL;
        int 
        //Output half dollars
        cout << "Half Dollars -> " << nHalf << endl;
        //Remove half dollars
        price -= nHalf*H_VAL;
        cout << "Would you like to purchase another item (y/n)?" << endl;
        cin >> answer;
    } while(answer !='y');

    //Exit, stage right
    return 0;
}

