/* 
 * Project: Savitch, Ch #8
 * Author:  David W. Smith
 *
 * Created on January 7, 2014, 9:05 AM
 */

// System functions
#include <iostream>
using namespace std;

// Constants
const float GRAVITY=32.127;

// Function Prototypes


int main(int argc, char** argv) {
    float time, frefall;
    // Input the time
    cout << "Input time in seconds: ";
    cin >> time;
    // Calculate distance dropped
    frefall = 1.0/2.0*GRAVITY*time*time;
    // Output result
    cout << "Distance Dropped - "<<frefall<<"(ft)"<<endl;
    // Exit, stage right!
    return 0;
}

