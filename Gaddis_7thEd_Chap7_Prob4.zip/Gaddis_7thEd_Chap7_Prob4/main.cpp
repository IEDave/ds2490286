/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr - Modified by David W. Smith
 * Created on January 27, 2014, 9:18 PM
 * Purpose:  Food for Monkeys
 *
 */

//System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

//Global Constants
const int COLS=7;

//Function Prototypes
int read(char [],int [][COLS]);
void write(int [][COLS],int [],int);
int min(int [][COLS],int);
int max(int [][COLS],int);
void avg(int [][COLS],int [],int);

int main(int argc, char** argv) {
    //Declare variables
    const int ROWS=20;
    int mnkFood[ROWS][COLS];
    int avgMnk[ROWS];
    char fName[]="./monkey.dat";
    //Read the data from the file
    int actSize=read(fName,mnkFood);
    //Calculate average food consumed per monkey
    avg(mnkFood,avgMnk,actSize);
    //Write the data
    write(mnkFood,avgMnk,actSize);
    //Output the minimum amount of food eaten by
    //a monkey
    cout<<"Smallest amount eaten by a monkey = "
        <<min(mnkFood,actSize)<<" ounces"<<endl;
    //Output the minimum amount of food eaten by
    //a monkey
    cout<<"Largest amount eaten by a monkey = "
        <<max(mnkFood,actSize)<<" ounces"<<endl;
    //Exit stage right
    return 0;
}

void avg(int monkey[][COLS],int avgMnk[],int ROWS){
    //Define local constant
    const float CVT_RND = 5.0e-1;
    //Define local variable
    float totMnk;
    //Using nested loops, calculate the average amount consumed per monkey
    for(int row=0;row<ROWS;row++){
        totMnk = 0.0;
        for(int col=0;col<COLS;col++){
            totMnk += static_cast<float>(monkey[row][col]);
        }
        avgMnk[row] = static_cast<int>(totMnk/static_cast<float>(COLS)+CVT_RND);
    }
    return;
}

int max(int monkey[][COLS],int ROWS){
    //Declare some small variable;
    int big=monkey[0][0];
    for(int row=0;row<ROWS;row++){
        for(int col=0;col<COLS;col++){
            if(big<monkey[row][col]){
                big=monkey[row][col];
            }
        }
    }
    return big;
}

int min(int monkey[][COLS],int ROWS){
    //Declare some small variable;
    int small=monkey[0][0];
    for(int row=0;row<ROWS;row++){
        for(int col=0;col<COLS;col++){
            if(small>monkey[row][col]){
                small=monkey[row][col];
            }
        }
    }
    return small;
}

void write(int monkey[][COLS],int avgMnk[],int ROWS){
    cout<<endl;
    cout<<"Monkey    M   T   W   T   F   S   S     Avg"<<endl;
    for(int row=0;row<ROWS;row++){
        cout<<"  "<<row+1<<"    ";
        for(int col=0;col<COLS;col++){
            cout<<setw(4)<<monkey[row][col];
        }
        cout << "      " << avgMnk[row];
        cout<<endl;
    }
    cout<<endl;
}

int read(char fName[],int monkey[][COLS]){
    //Open the file
    ifstream input;
    input.open(fName);
    //Read the data
    int row=0;
    while(input){
        for(int col=0;col<COLS;col++){
                input>>monkey[row][col];
        }
        row++;
    }
    //Close the file
    input.close();
    //return the number of rows
    return --row;
}


