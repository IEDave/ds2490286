/* 
 * File:   main.cpp
 * Author: David W. Smith
 * Created on January 6, 2014, 9:01 AM
 */
 
 
//System Libraries
#include <iostream>
using namespace std;


//Global Constants

//Functional Prototypes


/*
 * Function Main - where execution begins
 */
int main(int argc, char** argv) {
	// Output the string 'Hello World'
	cout<<"Hello World"<<endl;
	//Exit stage right
    return 0;
}

