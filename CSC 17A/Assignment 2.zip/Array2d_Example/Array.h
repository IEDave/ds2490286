/* 
 * File:   Array.h
 * Author: Dr. Mark E. Lehr
 * Created on September 23, 2013, 8:24 PM
 */

#ifndef ARRAY_H
#define	ARRAY_H

struct Array{
    unsigned int size;
    int *data;
};

#endif	/* ARRAY_H */

