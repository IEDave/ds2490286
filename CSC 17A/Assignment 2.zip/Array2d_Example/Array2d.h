/* 
 * File:   Array2d.h
 * Author: rcc
 *
 * Created on September 23, 2013, 9:01 PM
 */

#ifndef ARRAY2D_H
#define	ARRAY2D_H

struct Array2d{
    unsigned int row;
    unsigned int col;
    int **data;
};

#endif	/* ARRAY2D_H */

