/* 
 * File:   main.cpp
 * Author: David W. Smith
 * Created on January 21, 2014, 11:53 AM
 */
//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes
float stkPric(int,int,int);
int main(int argc, char** argv) {

    return 0;
}

